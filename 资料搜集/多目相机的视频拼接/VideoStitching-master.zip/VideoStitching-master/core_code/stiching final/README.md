# 使用OpenCV自带的Stitcher进行图像拼接

参考之前在博客园写的一篇文章：

- [关于OpenCV的stitching使用](http://www.cnblogs.com/CHLL55/p/4161551.html)